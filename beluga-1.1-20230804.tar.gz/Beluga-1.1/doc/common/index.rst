.. _common:

Common elements
===============

.. toctree::
   :maxdepth: 1

   lf
   contextual-lf
   lf-subordination
   Inductive Types (stub) <inductive-types>
