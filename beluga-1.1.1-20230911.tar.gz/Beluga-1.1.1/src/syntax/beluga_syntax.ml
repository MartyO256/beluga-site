module Syncom = Syncom
module Synext = Synext
module Synapx = Synapx
module Synint = Synint
module Ext = Synext
module Apx = Synapx
module Int = Synint
include Syncom
