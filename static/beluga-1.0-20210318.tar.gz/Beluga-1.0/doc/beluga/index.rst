.. _beluga:

Proofs as Programs with Beluga
==============================

.. note::

    This section of the documentation is unfinished.
