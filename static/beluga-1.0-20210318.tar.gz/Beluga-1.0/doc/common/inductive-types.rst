.. _inductive types:

Inductive Types
===============

.. attention::

    This page is a stub.
