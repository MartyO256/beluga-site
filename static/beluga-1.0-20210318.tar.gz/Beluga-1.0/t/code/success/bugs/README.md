Test cases in here are simply named according to the GitHub issue number that
used to evidence the bug.

e.g. `77.bel` contanis the code that demonstrates a bug reported in issue 77.

If a GitHub issue gives rise to multiple code snippets that produce the same or
different bugs, then the resulting test cases are numbered again.

e.g. `77-1.bel`, `77-2.bel`, and so on.
