(* -*- coding: utf-8; indent-tabs-mode: nil; -*- *)

(**
   Deciding the subordination relation
   
   @author Joshua Dunfield
*)

let dump = ref false

open Syntax.Int.LF
module Types = Store.Cid.Typ
module Constructors = Store.Cid.Term

module P = Pretty.Int.DefaultPrinter
module R = Pretty.Int.NamedRenderer

let (dprint, dprnt) = Debug.makeFunctions (Debug.toFlags [28])

(* getConstructorsAndTypes : Id.cid_typ -> (Id.cid_term * typ) list
 *
 * Given a type (e.g. nat), return the type's constructors along with their types
 * (e.g. [(z, nat), (suc, nat -> nat)])
 *)
let getConstructorsAndTypes a =
  let constructors = (Types.get a).Types.constructors in
  (* Reverse the list so coverage will be checked in the order that the
     constructors were declared, which is more natural to the user *)
  let constructors = List.rev constructors in   
  let addType c = (c, (Constructors.get c).Constructors.typ) in
    List.map addType constructors

let getTypes a =
  List.map Types.get (!Types.entry_list)


type memo = Entry of (Id.cid_typ * Id.cid_typ) * bool

type memo_table = memo list

let memo_table = (ref [] : memo_table ref)

let memoLookup argument =
  let rec inner = function
    | [] -> None
    | Entry(argument', result)::rest ->
        if argument = argument' then Some result
        else inner rest
  in
    inner (!memo_table)

let memoAdd (argument, result) =
  match memoLookup argument with
    | Some _ -> ()
    | None -> memo_table := Entry(argument, result) :: !memo_table

let clearMemoTable () =
  memo_table := []

let sully () =
  clearMemoTable()


(*
 * OVERVIEW
 *
 * The type B is subordinate to the type A if a term of type A can appear in a term of type B.
 * Subordination is entirely a data-level (LF) notion; it can be determined from the
 * LF signature alone.
 *
 * The usual reference for subordination is Roberto Virga's 1999 thesis.  However, Virga
 *  does not call it subordination; rather, he uses a "dependence relation" (pp. 55-59),
 *  also called "containment".
 *
 * The following statements are equivalent:
 *    "h-terms can contain g-terms"
 *    "h is subordinate to g"
 *    "g subordinates h"
 *)

let rec inspect acc = function
  | Atom(_, b, _spine) ->
      List.iter (fun acc1 -> memoAdd ((acc1, b), true)) acc;
      [b]

  | PiTyp((TypDecl(_name, tA1), _depend), tA2) ->      
      inspect (acc @ (inspect [] tA1)) tA2
(*  | Sigma _ -> *)

(*let is_subordinate_to a b = appears [] a b *)
let is_subordinate_to a b =
  match memoLookup (a, b) with
    | Some true -> true
    | None -> false

let populate () =
  let signat = List.map snd (List.concat (List.map getConstructorsAndTypes (!Types.entry_list))) in
    List.iter (fun tA -> let _ = inspect [] tA in ()) signat

let transclose () =
  let ts = !Types.entry_list in
  let pairs = List.concat (List.map (fun a -> List.map (fun b -> (a, b)) ts) ts) in
  let changed = ref true in
    while !changed do
      changed := false;
      List.iter
        (fun (a, b) -> if is_subordinate_to a b then
           List.iter
             (fun c -> if is_subordinate_to b c && not (is_subordinate_to a c) then
                         (memoAdd ((a, c), true); changed := true))
             ts)
        pairs
    done

let dump_subord () =
  clearMemoTable();
  print_string ("## Dumping subordination relation ##\n");
  print_string ("## The number of types is " ^ string_of_int (List.length !Types.entry_list) ^ "\n");
  populate();
  transclose();
  let typeList = List.rev (!Types.entry_list) in
  let dump_entry a b =
    if is_subordinate_to b a then
      print_string (R.render_cid_typ b ^ " ")
    else ()
  in let dump_line a =
      print_string ("--   " ^ R.render_cid_typ a ^ "  |>  ");
      List.iter (dump_entry a) typeList;
      print_string ("\n")
  in
    List.iter (fun a -> dump_line a) typeList


let dump_subord () =
  print_string ("## Dumping subordination relation ##\n");
  print_string ("## The number of types is " ^ string_of_int (List.length !Types.entry_list) ^ "\n");
  let typeList = List.rev (!Types.entry_list) in
  let dump_entry a b =
    if Types.is_subordinate_to a b then
      print_string (R.render_cid_typ b ^ " ")
    else ()
  in let dump_line a =
      print_string ("--   " ^ R.render_cid_typ a ^ "  |>  ");
      List.iter (dump_entry a) typeList;
      print_string ("\n")
  in
    List.iter (fun a -> dump_line a) typeList
