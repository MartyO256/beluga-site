(* -*- coding: utf-8; indent-tabs-mode: nil; -*- *)

(** Configuration / global state things should go in this module.
    Configuration perhaps more appropriate than global as we may at
    some point localize a configuration to particular computations. *)
